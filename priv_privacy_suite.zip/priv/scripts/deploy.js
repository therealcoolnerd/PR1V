const { ethers } = require('hardhat');

async function main() {
  // TODO: Deploy contracts and set up relationships
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
