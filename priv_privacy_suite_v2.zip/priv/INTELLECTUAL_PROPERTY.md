# Intellectual Property Notice

Copyright © 2025 A Really Cool Co. All rights reserved.

This repository and the software contained herein are proprietary and confidential.  
Unauthorized copying, distribution, modification, or commercial use of any portion of this codebase, 
including screenshots, diagrams, and documentation, is strictly prohibited without the express written consent of A Really Cool Co.

Use of the code is **limited to evaluation and internal development purposes** by employees and
contractors who have signed a valid NDA with A Really Cool Co.

For licensing inquiries, contact **legal@areallycoolco.com**.
